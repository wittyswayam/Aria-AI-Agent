# ARIA — Architecture & Design Decisions

## Overview

ARIA is a single-page application (SPA) with zero build steps. It's intentionally built with vanilla HTML/CSS/JS so anyone can read, fork, and modify it without a bundler, framework, or Node.js.

## Data Flow

```
User types message
  ↓
chat.js: sendMessage()
  ↓
api.js: callClaude(conversationHistory)
  ↓
POST https://api.anthropic.com/v1/messages
  {
    model:    "claude-sonnet-4-20250514",
    system:   SYSTEM_PROMPT,       ← context about user's emails, calendar, prefs
    messages: conversationHistory  ← full session history
  }
  ↓
Claude responds
  ↓
chat.js: addMessage('aria', reply)
  ↓
Rendered in chat UI
```

## Module Responsibilities

| File | Responsibility |
|------|---------------|
| `index.html` | DOM structure, script loading order |
| `src/styles/main.css` | All visual styles, design tokens |
| `src/utils/data.js` | Static mock data (swap for real APIs) |
| `src/utils/api.js` | Claude API wrapper + system prompt |
| `src/utils/helpers.js` | View switching, shared state, utilities |
| `src/components/chat.js` | Chat UI, message rendering, conversation history |
| `src/components/email.js` | Inbox list + detail pane |
| `src/components/calendar.js` | Week grid, event rendering |
| `src/components/memory.js` | Memory card grid |

## State Management

There's no framework state — just two plain objects:

```js
// helpers.js
const state = {
  currentView: 'chat',      // which panel is visible
  selectedEmailId: null,    // which email is open
};

// chat.js
let conversationHistory = []; // Claude message history (user + assistant turns)
let isTyping = false;         // prevents double-sends
```

## API Design Decisions

### Why browser-direct API calls?
Works immediately with zero backend for local dev and Claude.ai. For production, wrap in a backend proxy (see EXTENDING.md).

### Why full conversation history?
Claude has no memory between calls. Sending the full `conversationHistory` array on every request gives it context of the entire session. This is the standard pattern for multi-turn LLM applications.

### Why a system prompt with email/calendar context baked in?
Instead of real-time tool calls (which require a backend), ARIA's system prompt includes a snapshot of the user's inbox and calendar. This lets it answer context-aware questions ("what's on my calendar today?") in a single API call. In production, you'd call real APIs and inject fresh data into the system prompt before each request.

## Security Notes

- **API Key**: Never hardcode in client code. Use a backend proxy for production.
- **XSS**: All user and API content is run through `escapeHtml()` before rendering.
- **No eval**: No dynamic code execution anywhere.

## Performance

- No JavaScript framework (React, Vue, etc.) → zero bundle overhead
- Google Fonts loaded async with `display=swap`
- DOM updates are targeted (only re-render changed sections)
- Conversation history is kept in memory only (cleared on page reload)
