# ARIA — Extending with Real APIs

This guide shows how to replace the mock data with live integrations.

---

## 1. Backend Proxy (Recommended for Production)

Instead of calling the Anthropic API from the browser (which exposes your key), create a minimal backend:

### Express.js proxy (Node)

```js
// server.js
import express from 'express';
import Anthropic from '@anthropic-ai/sdk';

const app    = express();
const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

app.use(express.json());
app.use(express.static('.')); // serve index.html

app.post('/api/chat', async (req, res) => {
  const { messages, system } = req.body;

  const response = await client.messages.create({
    model:      'claude-sonnet-4-20250514',
    max_tokens: 1000,
    system,
    messages,
  });

  res.json({ content: response.content });
});

app.listen(8080, () => console.log('ARIA running on :8080'));
```

Then in `src/utils/api.js`, change the fetch URL:

```js
// Before (browser-direct):
const response = await fetch('https://api.anthropic.com/v1/messages', { ... });

// After (proxy):
const response = await fetch('/api/chat', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ messages, system: SYSTEM_PROMPT }),
});
```

---

## 2. Gmail Integration

### Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a project → Enable **Gmail API**
3. Create OAuth 2.0 credentials (Web Application)
4. Add `http://localhost:8080` to Authorized Origins

### Fetch inbox

```js
// After OAuth login, you'll have an access_token
async function fetchEmails(accessToken) {
  const res = await fetch(
    'https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=20&q=in:inbox',
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );
  const { messages } = await res.json();

  // Fetch each message
  const emails = await Promise.all(
    messages.map(m =>
      fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${m.id}`, {
        headers: { Authorization: `Bearer ${accessToken}` }
      }).then(r => r.json())
    )
  );

  // Parse headers
  return emails.map(e => {
    const headers = e.payload.headers;
    const get     = name => headers.find(h => h.name === name)?.value || '';
    return {
      id:      e.id,
      sender:  get('From'),
      subject: get('Subject'),
      time:    new Date(parseInt(e.internalDate)).toLocaleTimeString(),
      unread:  e.labelIds.includes('UNREAD'),
      body:    atob(e.payload.body?.data || ''), // base64 decode
    };
  });
}
```

### Then pass emails to ARIA's system prompt

```js
// In api.js, before calling Claude:
const liveEmails = await fetchEmails(accessToken);
const emailContext = liveEmails
  .slice(0, 5)
  .map(e => `- ${e.sender}: "${e.subject}" (${e.unread ? 'unread' : 'read'})`)
  .join('\n');

const DYNAMIC_SYSTEM = SYSTEM_PROMPT + `\n\nCurrent inbox:\n${emailContext}`;
```

---

## 3. Google Calendar Integration

### Fetch this week's events

```js
async function fetchCalendarEvents(accessToken) {
  const now   = new Date();
  const start = new Date(now.setDate(now.getDate() - now.getDay())).toISOString();
  const end   = new Date(now.setDate(now.getDate() + 7)).toISOString();

  const res = await fetch(
    `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${start}&timeMax=${end}&singleEvents=true&orderBy=startTime`,
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );

  const { items } = await res.json();
  return items.map(e => ({
    id:       e.id,
    title:    e.summary,
    start:    e.start.dateTime || e.start.date,
    end:      e.end.dateTime   || e.end.date,
    location: e.location,
  }));
}
```

---

## 4. Persistent Memory with localStorage

Simple client-side persistence (single device):

```js
// In memory.js

function saveMemories() {
  localStorage.setItem('aria-memories', JSON.stringify(MEMORIES));
}

function loadMemories() {
  const saved = localStorage.getItem('aria-memories');
  if (saved) MEMORIES.splice(0, MEMORIES.length, ...JSON.parse(saved));
}

// Call on page load:
loadMemories();

// Call after adding a memory:
function addMemory(memory) {
  MEMORIES.unshift({ ...memory, date: 'Just learned' });
  saveMemories();
  if (state.currentView === 'memory') renderMemory();
}
```

---

## 5. Streaming Responses

For a better UX where ARIA's response streams in token-by-token:

```js
// In api.js — replace callClaude() with streaming version:
async function callClaudeStream(messages, onToken, onDone) {
  const res = await fetch('/api/chat/stream', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages, system: SYSTEM_PROMPT }),
  });

  const reader  = res.body.getReader();
  const decoder = new TextDecoder();
  let   buffer  = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) { onDone(buffer); break; }

    const chunk = decoder.decode(value);
    // Parse SSE lines
    chunk.split('\n').forEach(line => {
      if (line.startsWith('data: ')) {
        const data = JSON.parse(line.slice(6));
        if (data.type === 'content_block_delta') {
          const token = data.delta?.text || '';
          buffer += token;
          onToken(token);
        }
      }
    });
  }
}
```

---

## 6. Voice Input

Add a microphone button using the Web Speech API:

```js
function startVoiceInput() {
  const recognition = new webkitSpeechRecognition();
  recognition.lang = 'en-US';
  recognition.onresult = (e) => {
    document.getElementById('chat-input').value = e.results[0][0].transcript;
    sendMessage();
  };
  recognition.start();
}
```

Add to `index.html`:
```html
<button class="btn" onclick="startVoiceInput()">🎙</button>
```
