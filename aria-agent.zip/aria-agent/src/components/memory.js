/**
 * memory.js — Memory & Knowledge view
 *
 * Renders ARIA's long-term memory cards.
 *
 * In production, persist memories to:
 * - localStorage (simple, client-only)
 * - Supabase / PlanetScale (multi-device sync)
 * - Notion API (see docs/EXTENDING.md)
 */

const MEMORY_COLORS = {
  preference: 'var(--accent2)',
  project:    'var(--teal)',
  contact:    'var(--green)',
  context:    'var(--amber)',
};

/**
 * Render all memory cards into the grid.
 */
function renderMemory() {
  const grid = document.getElementById('memory-grid');
  grid.innerHTML = MEMORIES.map(m => {
    const color = MEMORY_COLORS[m.type] || 'var(--text3)';
    return `
      <div class="memory-card">
        <div class="memory-type" style="color:${color};">
          <span>${m.icon}</span> ${escapeHtml(m.type)}
        </div>
        <div class="memory-title">${escapeHtml(m.title)}</div>
        <div class="memory-content">${escapeHtml(m.content)}</div>
        <div class="memory-date">${escapeHtml(m.date)}</div>
      </div>`;
  }).join('');
}

/**
 * Add a new memory entry programmatically.
 * Call this after ARIA extracts a new fact from conversation.
 *
 * @param {{ type: string, icon: string, title: string, content: string }} memory
 */
function addMemory(memory) {
  MEMORIES.unshift({
    ...memory,
    date: 'Just learned',
  });

  // Re-render if memory view is active
  if (state.currentView === 'memory') renderMemory();
}

/**
 * Search memories by keyword (simple client-side filter).
 * In production, use a vector DB for semantic search.
 *
 * @param {string} query
 * @returns {Array}
 */
function searchMemories(query) {
  const q = query.toLowerCase();
  return MEMORIES.filter(m =>
    m.title.toLowerCase().includes(q) ||
    m.content.toLowerCase().includes(q) ||
    m.type.toLowerCase().includes(q)
  );
}
