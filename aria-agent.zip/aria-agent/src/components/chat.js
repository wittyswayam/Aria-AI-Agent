/**
 * chat.js — Chat view logic
 *
 * Manages the conversation UI and API calls to Claude.
 */

// Per-session conversation history (cleared on page reload)
let conversationHistory = [];
let isTyping = false;

/**
 * Add the initial welcome message when the app loads.
 */
function addWelcomeMessage() {
  addMessage('aria', `Hey! I'm ARIA, your personal AI agent. I can read your emails, manage your calendar, answer questions from your notes, and handle tasks for you.\n\nWhat would you like help with today?`);
}

/**
 * Send a chip (quick-action button) as a message.
 * @param {HTMLElement} btn
 */
function sendChip(btn) {
  document.getElementById('chat-input').value = btn.textContent.trim();
  document.getElementById('chips').style.display = 'none';
  sendMessage();
}

/**
 * Clear all messages and reset conversation history.
 */
function clearChat() {
  document.getElementById('chat-messages').innerHTML = '';
  conversationHistory = [];
  document.getElementById('chips').style.display = 'flex';
  addMessage('aria', 'Chat cleared. What can I help you with?');
}

/**
 * Append a message bubble to the chat.
 *
 * @param {'aria'|'user'} role
 * @param {string} content        — display text
 * @param {Object|null} toolData  — optional tool card: { tool, data, colors }
 */
function addMessage(role, content, toolData = null) {
  const container = document.getElementById('chat-messages');
  const div       = document.createElement('div');
  div.className   = 'msg' + (role === 'user' ? ' user' : '');

  const time    = nowTime();
  const avatar  = role === 'aria' ? '✦' : 'U';
  const label   = role === 'aria' ? 'ARIA' : 'You';

  let toolHtml = '';
  if (toolData) {
    const rows = Object.entries(toolData.data)
      .map(([k, v]) => {
        const colorClass = toolData.colors?.[k] || '';
        return `<div class="tool-row">
          <span class="tool-key">${escapeHtml(k)}</span>
          <span class="tool-val ${colorClass}">${escapeHtml(String(v))}</span>
        </div>`;
      })
      .join('');

    toolHtml = `
      <div class="tool-card">
        <div class="tool-header"><span class="notif"></span>${escapeHtml(toolData.tool)}</div>
        ${rows}
      </div>`;
  }

  div.innerHTML = `
    <div class="msg-avatar ${role}">${avatar}</div>
    <div class="msg-body">
      <div class="msg-bubble">${escapeHtml(content).replace(/\n/g, '<br>')}</div>
      ${toolHtml}
      <div class="msg-time">${time} · ${label}</div>
    </div>`;

  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

/**
 * Show the animated "ARIA is typing" indicator.
 */
function showTyping() {
  const container = document.getElementById('chat-messages');
  const div       = document.createElement('div');
  div.className   = 'msg';
  div.id          = 'typing-indicator';
  div.innerHTML   = `
    <div class="msg-avatar aria">✦</div>
    <div class="msg-body">
      <div class="msg-bubble" style="padding:12px 14px;">
        <div class="typing-indicator">
          <div class="typing-dot"></div>
          <div class="typing-dot"></div>
          <div class="typing-dot"></div>
        </div>
      </div>
    </div>`;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

/**
 * Remove the typing indicator.
 */
function hideTyping() {
  const el = document.getElementById('typing-indicator');
  if (el) el.remove();
}

/**
 * Main send function — reads the input, calls Claude, renders the reply.
 */
async function sendMessage() {
  const input = document.getElementById('chat-input');
  const text  = input.value.trim();
  if (!text || isTyping) return;

  // Reset input
  input.value = '';
  input.style.height = 'auto';
  document.getElementById('chips').style.display = 'none';

  isTyping = true;
  document.getElementById('send-btn').disabled = true;

  // Render user message
  addMessage('user', text);
  conversationHistory.push({ role: 'user', content: text });

  showTyping();

  try {
    const reply = await callClaude(conversationHistory);
    hideTyping();

    conversationHistory.push({ role: 'assistant', content: reply });
    addMessage('aria', reply);

  } catch (err) {
    hideTyping();
    console.error('Claude API error:', err);
    addMessage('aria', `Sorry, I ran into an error: ${err.message}\n\nMake sure this is running from Claude.ai or a backend proxy is configured (see docs/EXTENDING.md).`);
  }

  isTyping = false;
  document.getElementById('send-btn').disabled = false;
  input.focus();
}

/**
 * Trigger inbox summarization from any view.
 */
function summarizeInbox() {
  switchView('chat', document.querySelectorAll('.nav-item')[0]);
  document.getElementById('chat-input').value = 'Summarize my inbox and tell me what needs attention today';
  sendMessage();
}
