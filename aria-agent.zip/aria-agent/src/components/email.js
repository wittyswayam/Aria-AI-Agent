/**
 * email.js — Inbox view logic
 *
 * Renders the email list and detail pane.
 * In production, replace EMAILS data with real Gmail API calls.
 * See docs/EXTENDING.md → "Gmail Integration"
 */

/**
 * Render the full email list in the sidebar.
 */
function renderEmailList() {
  const container = document.getElementById('email-items');
  container.innerHTML = EMAILS.map(e => `
    <div
      class="email-item ${e.unread ? 'unread' : ''} ${state.selectedEmailId === e.id ? 'active' : ''}"
      onclick="selectEmail(${e.id})"
    >
      <span class="email-time">${escapeHtml(e.time)}</span>
      <div class="email-sender">${escapeHtml(e.sender)}</div>
      <div class="email-subject">${escapeHtml(e.subject)}</div>
      <div class="email-preview">${escapeHtml(e.preview)}</div>
    </div>
  `).join('');

  // Update unread badge
  const unreadCount = EMAILS.filter(e => e.unread).length;
  const badge = document.getElementById('unread-badge');
  if (badge) badge.textContent = unreadCount;
  const countEl = document.getElementById('unread-count');
  if (countEl) countEl.textContent = unreadCount;
}

/**
 * Select an email and render its detail pane.
 * @param {number} id
 */
function selectEmail(id) {
  state.selectedEmailId = id;
  const email = EMAILS.find(e => e.id === id);
  if (!email) return;

  // Mark as read
  email.unread = false;
  renderEmailList();

  // Priority style overrides for the AI summary card
  const cardStyles = {
    high:   'background:rgba(245,101,101,0.08);border-color:rgba(245,101,101,0.25);',
    medium: 'background:rgba(245,166,35,0.08);border-color:rgba(245,166,35,0.25);',
    low:    '',
  };

  const priorityColors = {
    high:   'color:var(--red)',
    medium: 'color:var(--amber)',
    low:    'color:var(--green)',
  };

  document.getElementById('email-detail').innerHTML = `
    <div class="email-detail-header">
      <div class="email-detail-subject">${escapeHtml(email.subject)}</div>
      <div class="email-meta-row">
        <span>from: ${escapeHtml(email.sender)} &lt;${escapeHtml(email.email)}&gt;</span>
        <span>${escapeHtml(email.time)}</span>
        <span style="${priorityColors[email.priority] || ''}">${email.priority} priority</span>
      </div>
    </div>

    <div class="ai-summary-card" style="${cardStyles[email.priority] || ''}">
      <div class="ai-summary-label">
        <span class="notif"></span> ARIA Summary
      </div>
      <div class="ai-summary-text">${escapeHtml(email.aiSummary)}</div>
    </div>

    <div class="email-body">${escapeHtml(email.body)}</div>

    <div class="action-btns">
      <button class="btn primary" onclick="draftReply(${email.id})">Draft Reply with AI ✦</button>
      <button class="btn" onclick="archiveEmail(${email.id})">Archive</button>
      <button class="btn" onclick="scheduleFromEmail(${email.id})">Schedule Follow-up</button>
    </div>
  `;
}

/**
 * Open chat with a pre-filled "draft reply" prompt.
 * @param {number} id
 */
function draftReply(id) {
  const email = EMAILS.find(e => e.id === id);
  if (!email) return;
  switchView('chat', document.querySelectorAll('.nav-item')[0]);
  document.getElementById('chat-input').value =
    `Draft a reply to ${email.sender}'s email about: "${email.subject}"`;
  sendMessage();
}

/**
 * Open chat with a "schedule follow-up" prompt.
 * @param {number} id
 */
function scheduleFromEmail(id) {
  const email = EMAILS.find(e => e.id === id);
  if (!email) return;
  switchView('chat', document.querySelectorAll('.nav-item')[0]);
  document.getElementById('chat-input').value =
    `Schedule a follow-up for the email from ${email.sender} about: ${email.subject}`;
  sendMessage();
}

/**
 * Archive an email (mark as read, clear detail pane).
 * @param {number} id
 */
function archiveEmail(id) {
  const email = EMAILS.find(e => e.id === id);
  if (email) email.unread = false;

  state.selectedEmailId = null;
  document.getElementById('email-detail').innerHTML =
    '<div class="email-empty">Archived ✓</div>';
  renderEmailList();
}
