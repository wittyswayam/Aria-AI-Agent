/**
 * calendar.js — Calendar week-grid view
 *
 * Renders a 7-day week grid with time slots and events.
 * In production, replace EVENTS with Google Calendar API data.
 * See docs/EXTENDING.md → "Google Calendar Integration"
 */

const DAYS      = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const DATES     = [22, 23, 24, 25, 26, 27, 28]; // March 2026
const TODAY_COL = 3; // Index 3 = Wednesday Mar 25
const HOURS     = Array.from({ length: 11 }, (_, i) => i + 8); // 8am – 6pm

/**
 * Render the full calendar view: week grid + upcoming sidebar.
 */
function renderCalendar() {
  renderWeekGrid();
  renderUpcomingEvents();
}

/**
 * Build and inject the week grid HTML.
 */
function renderWeekGrid() {
  const grid = document.getElementById('week-grid');
  let html   = '';

  // Header row
  html += `<div class="week-day-header" style="background:var(--bg2);"></div>`;
  DAYS.forEach((day, i) => {
    const isToday = i === TODAY_COL;
    const numHtml = isToday
      ? `<div class="day-num" style="background:var(--accent);color:white;width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 2px;font-size:13px;box-shadow:0 0 10px var(--accent-glow);">${DATES[i]}</div>`
      : `<span class="day-num">${DATES[i]}</span>`;
    html += `<div class="week-day-header ${isToday ? 'today' : ''}">${numHtml}${day}</div>`;
  });

  // Time slot rows
  HOURS.forEach(h => {
    const label = formatHour(h);

    // Time label column
    html += `<div class="time-col"><div class="time-slot">${label}</div></div>`;

    // Day columns
    DAYS.forEach((_, di) => {
      const dayIndex  = di + 1; // 1-indexed to match EVENTS.day
      const dayEvents = EVENTS.filter(e => e.day === dayIndex);
      let evHtml      = '';

      dayEvents.forEach(ev => {
        if (Math.floor(ev.startH) === h) {
          const top    = (ev.startH - h) * 48;
          const height = ev.duration * 48 - 4;
          evHtml += `
            <div class="cal-event ${ev.type}" style="top:${top}px;height:${height}px;"
                 title="${escapeHtml(ev.title)}">
              ${escapeHtml(ev.title)}
            </div>`;
        }
      });

      html += `<div class="day-col"><div class="hour-cell">${evHtml}</div></div>`;
    });
  });

  grid.innerHTML = html;
}

/**
 * Render the upcoming events list in the sidebar.
 */
function renderUpcomingEvents() {
  const container = document.getElementById('upcoming-events');

  const colorMap = {
    purple: 'var(--accent2)',
    teal:   'var(--teal)',
    green:  'var(--green)',
    amber:  'var(--amber)',
  };

  const sorted = [...EVENTS].sort((a, b) => a.day - b.day || a.startH - b.startH);

  container.innerHTML = sorted.map(e => {
    const dayName  = DAYS[e.day - 1] || '';
    const timeStr  = formatHour(e.startH);
    const color    = colorMap[e.type] || 'var(--text2)';
    const duration = e.duration * 60;

    return `
      <div class="upcoming-event">
        <div class="upcoming-event-title">${escapeHtml(e.title)}</div>
        <div class="upcoming-event-time">${dayName} · ${timeStr} · ${duration}min</div>
        <span class="upcoming-event-tag"
              style="background:${color}20;color:${color};">
          ${e.type}
        </span>
      </div>`;
  }).join('');
}

/**
 * Quick-add an event by sending a natural language prompt to ARIA.
 */
function addQuickEvent() {
  const input = document.getElementById('quick-event');
  const text  = input.value.trim();
  if (!text) return;

  switchView('chat', document.querySelectorAll('.nav-item')[0]);
  document.getElementById('chat-input').value = `Add a calendar event: "${text}"`;
  input.value = '';
  sendMessage();
}
