/**
 * helpers.js — Shared utility functions
 */

// App state
const state = {
  currentView: 'chat',
  selectedEmailId: null,
};

/**
 * Switch the active view (chat / email / calendar / memory).
 * @param {string} view
 * @param {HTMLElement} navEl — the clicked nav item element
 */
function switchView(view, navEl) {
  // Update nav active state
  document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
  if (navEl) navEl.classList.add('active');

  // Show the correct content area
  document.querySelectorAll('.content-area').forEach(a => a.classList.remove('active'));
  document.getElementById('view-' + view).classList.add('active');

  state.currentView = view;

  // Update topbar
  const meta = VIEW_META[view];
  if (meta) {
    document.getElementById('topbar-title').textContent  = meta.title;
    document.getElementById('topbar-meta').textContent   = meta.meta;
    document.getElementById('action-btn').textContent    = meta.btn;
  }

  // Lazy-render views on first open
  if (view === 'email')    renderEmailList();
  if (view === 'calendar') renderCalendar();
  if (view === 'memory')   renderMemory();
}

/**
 * Handle the primary action button in the topbar.
 */
function handleTopbarAction() {
  switch (state.currentView) {
    case 'chat':
      document.getElementById('chat-input').value = 'Draft a new email to ';
      document.getElementById('chat-input').focus();
      break;
    case 'email':
      goToChat('Compose a new email to ');
      break;
    case 'calendar':
      document.getElementById('quick-event').focus();
      break;
    case 'memory':
      goToChat('Add a new memory: ');
      break;
  }
}

/**
 * Navigate to chat view and pre-fill the input.
 * @param {string} text
 */
function goToChat(text) {
  switchView('chat', document.querySelectorAll('.nav-item')[0]);
  document.getElementById('chat-input').value = text;
  document.getElementById('chat-input').focus();
}

/**
 * Format a 24h hour number to a display string.
 * @param {number} h
 * @returns {string}  e.g. "9:00 AM", "2:00 PM"
 */
function formatHour(h) {
  if (h === 12) return '12:00 PM';
  return h < 12 ? `${h}:00 AM` : `${h - 12}:00 PM`;
}

/**
 * Get current time string (HH:MM).
 * @returns {string}
 */
function nowTime() {
  return new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

/**
 * Escape HTML to prevent XSS when rendering user/API content.
 * @param {string} str
 * @returns {string}
 */
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/**
 * Auto-resize a textarea as the user types.
 * @param {HTMLTextAreaElement} el
 */
function autoResize(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 120) + 'px';
}

/**
 * Handle Enter key in the chat input (send on Enter, newline on Shift+Enter).
 * @param {KeyboardEvent} e
 */
function handleKey(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
}

/**
 * Handle "Clear chat" button.
 */
function handleClear() {
  clearChat();
}
