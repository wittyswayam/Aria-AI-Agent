/**
 * data.js — Mock data for ARIA
 *
 * In production, replace these with real API calls:
 * - EMAILS   → Gmail API  (see docs/EXTENDING.md)
 * - EVENTS   → Google Calendar API
 * - MEMORIES → Your database / Notion API
 */

const EMAILS = [
  {
    id: 1,
    sender: 'Alex Chen',
    email: 'alex@startup.io',
    subject: 'Q2 Product Roadmap Review',
    preview: 'Hey, wanted to loop you in on the roadmap changes before our Friday...',
    time: '9:41 AM',
    unread: true,
    priority: 'high',
    body: `Hey,

Wanted to loop you in on the roadmap changes before our Friday meeting. We've decided to push the mobile app launch to Q3 and instead focus on the API integrations the enterprise clients have been asking for.

Key changes:
- Mobile app: Q2 → Q3
- API v2: Accelerated to Q2
- Analytics dashboard: Stays in Q2

Can you review the attached PRD and share thoughts before EOD Thursday?

Best,
Alex`,
    aiSummary: 'Alex wants your review of Q2 roadmap changes (mobile pushed to Q3, API v2 accelerated). Response needed by Thursday EOD.',
  },
  {
    id: 2,
    sender: 'Sarah K.',
    email: 'sarah@design.co',
    subject: 'Design System v3 — final assets',
    preview: 'Attached are the final Figma links and exported SVGs for the new...',
    time: '8:15 AM',
    unread: true,
    priority: 'low',
    body: `Hi,

Attached are the final Figma links and exported SVGs for the new design system. Everything's been reviewed and signed off by the team.

Figma: [link] (editor access granted)
Component library: all 247 components updated
Dark mode: complete
Accessibility: WCAG 2.1 AA compliant

Let me know if you need any adjustments!

Sarah`,
    aiSummary: 'Design System v3 is complete. 247 components, dark mode, WCAG AA. Figma access granted. No action needed unless changes required.',
  },
  {
    id: 3,
    sender: 'Investor Update',
    email: 'noreply@updates.vc',
    subject: '[Portfolio] March Digest',
    preview: "Here's your monthly portfolio summary and key metrics across...",
    time: 'Yesterday',
    unread: true,
    priority: 'medium',
    body: `Monthly Portfolio Digest — March 2026

Your portfolio performance this month:
Total value: $284,320 (+3.2%)
Top performer: NVDA (+12.1%)
Worst performer: META (-4.3%)

Market conditions: Moderate volatility expected through April due to Fed decisions and tech earnings season.

Action items: Review your allocation in the AI/ML sector (currently 34% of portfolio).`,
    aiSummary: 'Portfolio up 3.2% this month. NVDA top performer. Consider reviewing AI/ML allocation at 34%.',
  },
  {
    id: 4,
    sender: 'GitHub',
    email: 'noreply@github.com',
    subject: '[aria-agent] PR #47 merged',
    preview: 'Pull request #47 was merged into main by @devbot...',
    time: 'Yesterday',
    unread: false,
    priority: 'low',
    body: `Pull request #47 "feat: add streaming support for tool calls" was merged into main.

Merged by: @devbot
2 commits, +342 -87 lines
All checks passed ✓

View the changes at github.com/your-repo/aria-agent/pull/47`,
    aiSummary: 'PR #47 merged to main — streaming tool call support added. CI passed.',
  },
  {
    id: 5,
    sender: 'Team Standup Bot',
    email: 'bot@slack.com',
    subject: 'Daily Standup Summary — Mar 24',
    preview: "Yesterday's standup notes: Priya: finished auth module...",
    time: 'Yesterday',
    unread: false,
    priority: 'medium',
    body: `Daily Standup — March 24, 2026

Priya: Finished auth module, working on email integration tests
Marcus: Deployed staging env, investigating latency spike in EU region
Jordan: Design review at 2pm, finalizing onboarding flow

Blockers: EU latency issue needs DevOps attention
Next meeting: Tomorrow 9:30am`,
    aiSummary: 'EU latency spike needs attention. Priya on email integration. Design review today at 2pm.',
  }
];

/**
 * Calendar events
 * day: 1=Sun, 2=Mon, 3=Tue, 4=Wed (today), 5=Thu, 6=Fri, 7=Sat
 * startH: 24hr hour (9 = 9am, 14 = 2pm)
 * duration: hours (0.5 = 30min, 1 = 1hr)
 * type: 'purple' | 'teal' | 'green' | 'amber'
 */
const EVENTS = [
  { id: 1, title: 'Team Standup',   day: 2, startH: 9,  duration: 0.5, type: 'teal'   },
  { id: 2, title: 'Product Review', day: 2, startH: 14, duration: 1,   type: 'purple' },
  { id: 3, title: '1:1 w/ Manager', day: 3, startH: 10, duration: 1,   type: 'green'  },
  { id: 4, title: 'Design Sync',    day: 4, startH: 13, duration: 1.5, type: 'amber'  },
  { id: 5, title: 'API Planning',   day: 5, startH: 11, duration: 2,   type: 'purple' },
  { id: 6, title: 'Demo Day Prep',  day: 5, startH: 15, duration: 1,   type: 'teal'   },
];

/**
 * Memory entries — ARIA's long-term context about you
 * type: 'preference' | 'project' | 'contact' | 'context'
 */
const MEMORIES = [
  {
    type: 'preference',
    icon: '◈',
    title: 'Prefers async comms',
    content: 'User prefers Slack over email for internal comms. Avoids meetings before 9am.',
    date: 'Learned 2 weeks ago',
  },
  {
    type: 'project',
    icon: '◆',
    title: 'Project: ARIA Agent',
    content: 'Building a personal AI agent. Stack: Next.js, Anthropic API, Postgres. Deploy target: end of Q2.',
    date: 'Learned 1 month ago',
  },
  {
    type: 'contact',
    icon: '◎',
    title: 'Alex Chen — PM',
    content: 'Works at startup.io. Main point of contact for roadmap. Prefers detailed written updates.',
    date: 'Learned 3 weeks ago',
  },
  {
    type: 'context',
    icon: '⬡',
    title: 'Work context',
    content: 'Senior engineer at a 30-person startup. Currently leading the platform team. Reporting to CTO.',
    date: 'Learned 2 months ago',
  },
  {
    type: 'preference',
    icon: '◈',
    title: 'Writing style',
    content: 'Direct, technical, uses bullet points. Dislikes long intros. Prefers "you" over "one".',
    date: 'Learned 3 weeks ago',
  },
  {
    type: 'context',
    icon: '⬡',
    title: 'Goals Q2 2026',
    content: 'Ship API v2, hire 2 engineers, reduce latency to <100ms p99. Personal: read 2 books, run 5K.',
    date: 'Learned 1 week ago',
  },
];

// View metadata
const VIEW_META = {
  chat:     { title: 'Chat with ARIA',      meta: 'Personal AI Agent · Session #47', btn: 'Compose'    },
  email:    { title: 'Inbox',               meta: 'Gmail · 3 unread',                btn: 'Compose'    },
  calendar: { title: 'Calendar',            meta: 'Google Calendar · Mar 2026',      btn: 'New Event'  },
  memory:   { title: 'Knowledge & Memory',  meta: 'Long-term knowledge base',        btn: 'Add Memory' },
};
