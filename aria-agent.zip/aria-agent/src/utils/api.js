/**
 * api.js — Anthropic Claude API wrapper
 *
 * Handles all communication with the Claude API.
 *
 * ⚠️  IMPORTANT — API KEY SECURITY:
 * This file calls the API directly from the browser.
 * This is fine for local dev and Claude.ai artifact environments.
 *
 * For production deployments, use a backend proxy instead:
 *   - See docs/EXTENDING.md → "Backend Proxy" section
 *   - Replace the fetch URL with your own /api/chat endpoint
 *   - Store ANTHROPIC_API_KEY server-side only (never in client code)
 */

const CLAUDE_MODEL = 'claude-sonnet-4-20250514';
const API_URL      = 'https://api.anthropic.com/v1/messages';
const MAX_TOKENS   = 1000;

/**
 * ARIA's system prompt.
 * Edit this to change ARIA's persona, capabilities, and context.
 */
const SYSTEM_PROMPT = `You are ARIA, a sophisticated personal AI agent. You're connected to the user's Gmail and Google Calendar. You have access to their email summaries and calendar events.

Current context:
- Today is Wednesday, March 25, 2026
- User has 3 unread emails:
  1. Alex Chen (Q2 roadmap review — needs response by Thursday EOD). High priority.
  2. Sarah K. (Design System v3 complete — no action needed). Low priority.
  3. Portfolio digest (up 3.2%, review AI/ML allocation). Medium priority.
- Today's calendar: Team Standup at 9am (30 min), Product Review at 2pm (1 hr)
- User is a senior engineer at a ~30-person startup, leading the platform team, reporting to CTO
- They prefer direct, technical communication. Bullet points. No fluff.

You have these tools available (simulate them realistically when relevant):
- read_email(id)          → Read a specific email
- list_emails()           → List inbox with summaries
- send_email(to, subject, body) → Send or draft an email
- schedule_event(title, time, duration) → Add a calendar event
- list_events(date)       → Get calendar for a date
- search_memory(query)    → Look up long-term context about the user
- web_search(query)       → Search the internet for current info

When you use a tool, describe it naturally inline: "Let me check your inbox..." then give the result.

Tone: concise, direct, slightly dry. Like a very capable EA who's also technical.
Format: use bullet points for lists. Keep responses under 150 words unless the task genuinely requires more.
Never say "Certainly!" or "Great question!" — just answer.`;

/**
 * Send a message to Claude and get a response.
 *
 * @param {Array<{role: 'user'|'assistant', content: string}>} messages
 * @returns {Promise<string>} The assistant's reply text
 */
async function callClaude(messages) {
  const response = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      // API key is injected by the Claude.ai environment.
      // For your own backend, add: 'x-api-key': YOUR_KEY
    },
    body: JSON.stringify({
      model:      CLAUDE_MODEL,
      max_tokens: MAX_TOKENS,
      system:     SYSTEM_PROMPT,
      messages:   messages,
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `API error ${response.status}`);
  }

  const data = await response.json();

  // Extract text from the content array
  const textBlock = data.content?.find(block => block.type === 'text');
  if (!textBlock) throw new Error('No text in API response');

  return textBlock.text;
}

/**
 * Simulates a tool use block for display in the chat UI.
 * In production, you'd call real APIs here and format the results.
 *
 * @param {string} toolName
 * @param {Object} data       key-value pairs to display
 * @param {Object} colors     optional: map keys to color classes ('green'|'amber'|'accent')
 * @returns {{ tool: string, data: Object, colors: Object }}
 */
function makeToolCard(toolName, data, colors = {}) {
  return { tool: toolName, data, colors };
}
